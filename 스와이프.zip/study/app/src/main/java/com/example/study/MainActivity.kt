package com.example.study

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.study.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root) //바인딩

        val fragmentList = listOf(FragmentA(), FragmentB(), FragmentC(), FragmentD()) //프래그먼트 목록 생성

        val adapter = FragmentAdapter(this) //adapter 생성
        adapter.fragmentList = fragmentList  //앞에서 생선한 프래그먼트 목록을 저장.
        binding.viewPager.adapter = adapter //레이아웃의 viewPager를 import하고 어댑터를 적용
    }

}