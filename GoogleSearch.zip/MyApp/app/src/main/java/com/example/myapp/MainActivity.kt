package com.example.myapp

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import com.example.myapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater) //바인딩
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.progressBar.visibility = View.GONE //로딩바 가리기

        initWebView() //웹뷰 초기화

        /* 검색버튼 클릭시 검색*/
        binding.button.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                binding.webView.loadUrl("https://www.google.co.kr/search?q="+binding.searchView.text)
            }
        })

    }

        /* 웹뷰 초기화 */
        @SuppressLint("SetJavaScriptEnabled")
        fun initWebView() {
            //1. 웹뷰클라이언트 연결(로딩 시작 / 끝 받아오기)
            binding.webView.webViewClient = object : WebViewClient() {
                //1) 로딩 시작
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    binding.progressBar.visibility = View.VISIBLE //로딩이 시작되면 로딩바 보이기
                }

                //2) 로딩 끝
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.progressBar.visibility = View.GONE //로딩이 끝나면 로딩바 없애기
                }

                //3)외부 브라우저가 아닌 웹뷰 자체에서 url 호출
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (view != null && url != null) {
                        view.loadUrl(url)
                        return true
                    }
                    return false
                }
            }

            //2. WebSetting: 웹뷰의 각종 설정을 정하기
            val ws : WebSettings = binding.webView.settings
            //3. 자바스크립트 사용 허가
            ws.javaScriptEnabled = true
            //4. 웹페이지 호출
            binding.webView.loadUrl("https://www.google.co.kr")
        }

        /* 뒤로가기 동작 컨트롤 */
        override fun onBackPressed() {
            if(binding.webView.canGoBack()) { //이전페이지가 있으면
                binding.webView.goBack() //이전페이지로 이동
            } else {
                super.onBackPressed() //없으면 앱 종료
            }
        }
}

