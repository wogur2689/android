package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.example.myapplication.databinding.ActivityMainBinding
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    var total = 0
    var started = false //true면 동작 false면 정지

    // 화면에 시간값을 출력하는 핸들러
    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            val minute = String.format("%02d", total/60) //분
            val second = String.format("%02d", total%60) //초
            binding.textTimer.text = "$minute:$second"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        //button Start!
        binding.buttonStart.setOnClickListener {
            started = true
            thread(start=true) {
                while(started) { //타이머 반복
                    Thread.sleep(1000) //1초마다 증가
                    if(started) {
                        total += 1
                        handler?.sendEmptyMessage(0) //핸들러에 메시지 전송
                    }
                }
            }
        }

        //button Stop!
        binding.buttonStop.setOnClickListener {
            if(started) {
                started = false //종료
                total = 0
                binding.textTimer.text = "00:00"
            }
        }

    }
}