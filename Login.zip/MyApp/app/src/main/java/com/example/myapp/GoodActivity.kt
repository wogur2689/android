package com.example.myapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class GoodActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_good)

        val intent = intent //intent 받기

        val result = findViewById<TextView>(R.id.loginResult) //text뷰 찾아서 저장.

        if(intent.getStringExtra("result").toString() != "fail"){
            /* 로그인 성공 토스트 */
            Toast.makeText(this, "로그인에 성공하였습니다.", Toast.LENGTH_LONG).show()
            result.text = "SUCCESS"
        } else {
            /* 로그인 실패 토스트 */
            Toast.makeText(this, "로그인에 실패하였습니다.", Toast.LENGTH_LONG).show()
            result.text = "FAIL"
        }
    }
}