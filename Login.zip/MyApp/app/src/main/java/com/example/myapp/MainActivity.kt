package com.example.myapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val userId = findViewById<EditText>(R.id.editUserId) //userId
        val password = findViewById<EditText>(R.id.editPassword) //password
        val loginBtn = findViewById<Button>(R.id.loginBtn) //loginBtn

        loginBtn.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, GoodActivity::class.java).apply {
                putExtra("userId", userId.text.toString())
                putExtra("password", password.text.toString())
                if(userId.text.toString() != "test") {
                    Toast.makeText(applicationContext, "존재하지 않는 계정입니다.", Toast.LENGTH_LONG).show()
                    putExtra("result", "fail")
                }
            }
            startActivity(intent)
        })
    }
}